% Add your code for Task 2 in this file

