% Add your code for Task 3 in this file

