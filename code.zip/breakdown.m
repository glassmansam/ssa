function breakdownTime = breakdown()
    U = rand();
    breakdownTime = (20 - 10) * U + 10;
end